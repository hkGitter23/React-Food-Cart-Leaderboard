import Link from "next/link";
import { notFound } from "next/navigation";
import { TRUCKS } from "@/lib/trucks";

export default async function FoodcartPage({ params }) {
  // Next.js 16: params is a Promise in server components
  const { slug } = await params;

  // decode in case slug has %20 etc.
  const decoded = decodeURIComponent(slug || "").toLowerCase();

  // match by slug OR id (depending on what you used)
  const truck =
    TRUCKS.find((t) => (t.slug || "").toLowerCase() === decoded) ||
    TRUCKS.find((t) => (t.id || "").toLowerCase() === decoded);

  if (!truck) return notFound();

  return (
    <main style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <Link href="/" style={{ textDecoration: "none" }}>
        ← Back to Leaderboard
      </Link>

      <h1 style={{ marginTop: 16 }}>{truck.name}</h1>

      <p style={{ marginTop: 6, opacity: 0.8 }}>
        <strong>Category:</strong> {truck.category}
      </p>

      <p style={{ marginTop: 6, opacity: 0.8 }}>
        <strong>Location:</strong> {truck.location}
      </p>

      {(truck.price || truck.priceRange) && (
        <p style={{ marginTop: 6, opacity: 0.8 }}>
          <strong>Price:</strong>{" "}
          {truck.price ? truck.price : ""}
          {truck.price && truck.priceRange ? " • " : ""}
          {truck.priceRange ? truck.priceRange : ""}
        </p>
      )}

      <div
        style={{
          marginTop: 20,
          padding: 16,
          border: "1px solid rgba(0,0,0,0.1)",
          borderRadius: 10,
          background: "white",
        }}
      >
        <h2 style={{ marginTop: 0 }}>Menu</h2>

        {Array.isArray(truck.menu) && truck.menu.length > 0 ? (
          <ul style={{ margin: 0, paddingLeft: 18 }}>
            {truck.menu.map((item) => (
              <li key={item.name} style={{ marginBottom: 8 }}>
                <strong>{item.name}</strong>
                {item.price ? ` — ${item.price}` : ""}
                {item.desc ? (
                  <div style={{ opacity: 0.75 }}>{item.desc}</div>
                ) : null}
              </li>
            ))}
          </ul>
        ) : (
          <p style={{ opacity: 0.75 }}>Coming soon — menu not added yet.</p>
        )}
      </div>
    </main>
  );
}